/*package RajaYonandroRuslitoJBusAF;

public interface FileParser
{
    public Object write();
    public boolean read(String obj);
}*/
