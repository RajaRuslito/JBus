package com.RajaYonandroRuslitoJBusAF;

public interface Predicate<T> {

    public boolean predicate(T val);
}
