package com.RajaYonandroRuslitoJBusAF;

public enum Type
{
    REBATE, DISCOUNT;
}
