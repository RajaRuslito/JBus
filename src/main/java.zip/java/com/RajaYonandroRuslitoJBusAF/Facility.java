package com.RajaYonandroRuslitoJBusAF;


public enum Facility{
    AC,
    LUNCH,
    TOILET,
    COOL_BOX,
    WIFI,
    LCD_TV,
    ELECTRIC_SOCKET, 
    LARGE_BAGGAGE;
}
