package com.RajaYonandroRuslitoJBusAF;

public enum BusType
{
    REGULER,
    HIGH_DECKER,
    MINIBUS,
    DOUBLE_DECKER;
}
